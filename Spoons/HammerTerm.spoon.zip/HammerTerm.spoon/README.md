# It's HammerTerm

Rather than rely on global hotkeys from my terminal app, this hammerspoon addon does the "right" thing for whatever terminal I'm currently using (at the moment, [WezTerm](https://wezfurlong.org/wezterm/) is my go-to).

By default it's bound to `Cmd-Ctrl-'`
